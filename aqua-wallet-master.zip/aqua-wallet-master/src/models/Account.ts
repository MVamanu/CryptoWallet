export interface Account {
    privateKey: string,
    address: string,
    balance: string,
}