export interface Transaction {
    hash: string,
    from_address: string,
    to_address: string,
    value: string,
    block_timestamp: string,
};